package com.zirexhub.autoplayer

import android.content.Context

/** Small wrapper around SharedPreferences for every user setting. */
object Prefs {
    const val MODE_AI = "ai"
    const val MODE_OFFLINE = "offline"

    // Editable in the app. Change it if your account uses a different model name.
    const val DEFAULT_MODEL = "claude-sonnet-5-5"

    const val DEFAULT_GOAL =
        "Work out which game this is and how it is played, then play it to win. " +
            "Clear tutorials, pop-ups and level-complete screens and keep progressing."

    private fun sp(c: Context) = c.getSharedPreferences("zirex_autoplayer", Context.MODE_PRIVATE)

    fun mode(c: Context): String = sp(c).getString("mode", MODE_AI) ?: MODE_AI

    fun apiKey(c: Context): String = sp(c).getString("api_key", "") ?: ""

    fun model(c: Context): String =
        (sp(c).getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL).ifBlank { DEFAULT_MODEL }

    fun goal(c: Context): String =
        (sp(c).getString("goal", "") ?: "").ifBlank { DEFAULT_GOAL }

    fun rawGoal(c: Context): String = sp(c).getString("goal", "") ?: ""

    fun delayMs(c: Context): Long = sp(c).getLong("delay_ms", 1500L).coerceIn(300L, 15000L)

    fun save(c: Context, mode: String, apiKey: String, model: String, goal: String, delayMs: Long) {
        sp(c).edit()
            .putString("mode", mode)
            .putString("api_key", apiKey.trim())
            .putString("model", model.trim())
            .putString("goal", goal.trim())
            .putLong("delay_ms", delayMs.coerceIn(300L, 15000L))
            .apply()
    }
}
