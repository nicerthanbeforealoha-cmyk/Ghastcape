package com.zirexhub.autoplayer

import android.graphics.Bitmap

/**
 * One thing the agent can do on the screen.
 * All coordinates are NORMALIZED (0.0 .. 1.0) so they do not depend on screen size.
 */
sealed class GameAction {
    data class Tap(val x: Float, val y: Float, val count: Int = 1) : GameAction()
    data class LongPress(val x: Float, val y: Float, val ms: Long = 700L) : GameAction()
    data class Swipe(
        val x1: Float,
        val y1: Float,
        val x2: Float,
        val y2: Float,
        val ms: Long = 300L,
    ) : GameAction()

    data class Wait(val ms: Long = 1000L) : GameAction()
    object Back : GameAction()
    data class Finish(val reason: String) : GameAction()
}

/** What a brain decided: the action, a short human note, and a compact label for the history. */
data class Decision(val action: GameAction, val note: String, val label: String)

/** Everything a brain gets besides the screenshot. */
class AgentContext(
    val goal: String,
    val history: List<String>,
    /** 0..1 fraction of the screen that changed since the previous step (null on the first step). */
    val changeScore: Float?,
    /** How many steps in a row did not visibly change the screen. */
    val stuckCount: Int,
)

/** A "brain" looks at one frame and picks the next action. */
interface Brain {
    fun decide(frame: Bitmap, ctx: AgentContext): Decision
}
