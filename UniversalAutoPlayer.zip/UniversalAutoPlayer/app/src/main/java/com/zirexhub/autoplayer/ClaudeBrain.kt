package com.zirexhub.autoplayer

import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.roundToInt

/**
 * The "AI player": sends the current screenshot plus recent history to Claude (vision) and gets
 * back exactly one action as JSON. Because it re-reads the screen every step, it adapts to any
 * game, any layout and any surprise (pop-ups, new levels, game over screens).
 */
class ClaudeBrain(private val apiKey: String, private val model: String) : Brain {

    /** Thrown for 401/403 so the agent stops instead of retrying forever. */
    class AuthException(message: String) : Exception(message)

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        val img = FrameTools.encode(frame, 1024, 72)

        val content = JSONArray()
            .put(
                JSONObject()
                    .put("type", "image")
                    .put(
                        "source",
                        JSONObject()
                            .put("type", "base64")
                            .put("media_type", "image/jpeg")
                            .put("data", img.base64),
                    ),
            )
            .put(JSONObject().put("type", "text").put("text", buildPrompt(ctx, img.width, img.height)))

        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 600)
            .put("system", SYSTEM_PROMPT)
            .put(
                "messages",
                JSONArray().put(JSONObject().put("role", "user").put("content", content)),
            )

        return parse(post(body.toString()), img.width, img.height)
    }

    private fun buildPrompt(ctx: AgentContext, w: Int, h: Int): String = buildString {
        appendLine("Goal from the user: ${ctx.goal}")
        appendLine("Image size: ${w}x${h} pixels.")
        if (ctx.history.isEmpty()) {
            appendLine("This is the first step.")
        } else {
            appendLine("Your recent actions, oldest first:")
            ctx.history.forEach { appendLine(it) }
        }
        ctx.changeScore?.let {
            val pct = String.format(Locale.US, "%.1f", it * 100f)
            appendLine("Screen change since your last action: $pct%")
        }
        if (ctx.stuckCount >= 2) {
            appendLine(
                "WARNING: your last ${ctx.stuckCount} actions did not visibly change the screen. " +
                    "Do something different: another target, a swipe, a long press, or wait for an animation.",
            )
        }
        append("Choose the next action. Reply with the JSON object only.")
    }

    private fun post(json: String): String {
        val conn = URL(API_URL).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 90_000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code == 401 || code == 403) throw AuthException("HTTP $code: ${errorMessage(text)}")
            if (code !in 200..299) throw IOException("HTTP $code: ${errorMessage(text)}")
            return text
        } finally {
            conn.disconnect()
        }
    }

    private fun errorMessage(text: String): String = try {
        JSONObject(text).getJSONObject("error").getString("message")
    } catch (_: Exception) {
        text.take(120)
    }

    /** Coordinates from the model are pixels of the image we sent; convert to 0..1. */
    private fun norm(v: Double, dim: Int): Float =
        (if (v <= 1.0) v else v / dim).toFloat().coerceIn(0f, 1f)

    private fun parse(reply: String, w: Int, h: Int): Decision {
        val blocks = JSONObject(reply).optJSONArray("content") ?: throw IOException("Empty reply")
        val sb = StringBuilder()
        for (i in 0 until blocks.length()) {
            val b = blocks.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        val text = sb.toString()
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) throw IOException("No JSON in reply: ${text.take(80)}")

        val j = JSONObject(text.substring(start, end + 1))
        val note = j.optString("plan").ifBlank { j.optString("observation") }.take(160)

        val x = norm(j.optDouble("x", 0.5), w)
        val y = norm(j.optDouble("y", 0.5), h)
        val x2 = norm(j.optDouble("x2", 0.5), w)
        val y2 = norm(j.optDouble("y2", 0.5), h)
        val px = (x * w).roundToInt()
        val py = (y * h).roundToInt()
        val ms = j.optLong("duration_ms", 0L)

        return when (j.optString("action").lowercase(Locale.US).trim()) {
            "tap", "click" -> {
                val count = j.optInt("count", 1).coerceIn(1, 12)
                val suffix = if (count > 1) " x$count" else ""
                Decision(GameAction.Tap(x, y, count), note, "tap($px,$py)$suffix")
            }
            "double_tap" -> Decision(GameAction.Tap(x, y, 2), note, "double_tap($px,$py)")
            "long_press", "hold" -> {
                val d = if (ms > 0) ms.coerceIn(300L, 3000L) else 800L
                Decision(GameAction.LongPress(x, y, d), note, "long_press($px,$py,${d}ms)")
            }
            "swipe", "drag", "scroll" -> {
                val d = if (ms > 0) ms.coerceIn(80L, 2500L) else 300L
                val ex = (x2 * w).roundToInt()
                val ey = (y2 * h).roundToInt()
                Decision(GameAction.Swipe(x, y, x2, y2, d), note, "swipe($px,$py -> $ex,$ey,${d}ms)")
            }
            "wait" -> {
                val d = if (ms > 0) ms.coerceIn(300L, 5000L) else 1000L
                Decision(GameAction.Wait(d), note, "wait(${d}ms)")
            }
            "back" -> Decision(GameAction.Back, note, "back")
            "finish", "done", "stop" -> {
                val reason = j.optString("reason").ifBlank { note }
                Decision(GameAction.Finish(reason), note, "finish")
            }
            else -> Decision(GameAction.Wait(1000L), "Unknown action, waiting", "wait(1000ms)")
        }
    }

    companion object {
        private const val API_URL = "https://api.anthropic.com/v1/messages"

        private val SYSTEM_PROMPT = """
You are the brain of a universal game-playing agent running on an Android phone. Every turn you receive a screenshot of the current screen and must choose exactly ONE touch action. Your goal is to play whatever game is on screen as well as possible and WIN: finish levels, reach high scores, complete objectives.

How to work:
- First work out which game this is, what the objective is and how it is controlled, using the screenshot, any tutorial text and your recent action history.
- Dismiss tutorials, reward dialogs and 'continue' / 'next level' / 'play again' prompts so play keeps going. When a level is won, move on to the next one.
- Adapt. If your recent actions had no effect, or the screen is not what you expected, try something different: another target, a swipe, a longer press, or waiting for an animation to finish.
- Prefer decisive, high-value moves. In tapping or clicker games use 'count' to tap many times in one step. In puzzle games think a few moves ahead. You only get to act about once every few seconds, so for timing-critical moments use 'wait' and act when the moment is right.

Safety rules (never break these):
- Never buy anything. Never tap purchase, subscribe, price or real-money offer buttons.
- Never type or enter passwords, payment details or personal information, and never log in to accounts.
- Never tap advertisement content. If an ad is showing, look for its close (X) or skip button, or wait for it to appear; use 'back' if there is no other way out.
- Stay inside the game. If the screen is not a game (home screen, settings, another app), use 'finish' and explain why.
- Ignore the small floating control chip with PLAY/STOP at the screen edge. It belongs to the agent.

Reply with ONLY one JSON object, no markdown, no extra text, in this shape:
{"observation":"<what you see, short>","plan":"<why this action, short>","action":"tap|long_press|swipe|wait|back|finish","x":0,"y":0,"x2":0,"y2":0,"count":1,"duration_ms":0,"reason":""}

Coordinates are pixels in the image you were given (origin top-left). 'x','y' is the tap/press point or the swipe start; 'x2','y2' is the swipe end. Leave out fields that do not apply. Use 'finish' only when the whole game or objective is complete, or progress is truly impossible.
        """.trimIndent()
    }
}
