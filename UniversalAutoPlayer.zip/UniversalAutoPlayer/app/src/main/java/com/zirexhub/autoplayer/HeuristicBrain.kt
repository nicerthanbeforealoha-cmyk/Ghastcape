package com.zirexhub.autoplayer

import android.graphics.Bitmap
import android.graphics.Color
import java.util.Locale
import java.util.Random
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * The "offline explorer": no internet, no API key. It cannot understand a game, but it LEARNS by
 * trial and error. The screen is split into a grid; every cell (plus four swipe directions) is an
 * "arm" of a bandit. The reward for an arm is how much the screen changed after using it.
 * Arms that make things happen get used more, with a bias towards colourful, button-like areas.
 * Good for tap-to-progress, idle/clicker and simple casual games. Use AI mode for real thinking.
 */
class HeuristicBrain : Brain {
    private val cols = 6
    private val rows = 10
    private val cells = cols * rows
    private val arms = cells + 4 // + swipe left, right, up, down

    private val value = FloatArray(arms)
    private val uses = IntArray(arms)
    private var t = 1
    private var lastArm = -1
    private val rnd = Random()

    override fun decide(frame: Bitmap, ctx: AgentContext): Decision {
        // 1) Credit the previous action with how much the screen changed.
        val reward = ctx.changeScore
        if (lastArm >= 0 && reward != null) {
            uses[lastArm]++
            val rate = maxOf(1f / uses[lastArm], 0.25f)
            val target = reward.coerceAtMost(0.5f) * 2f
            value[lastArm] += (target - value[lastArm]) * rate
            // A totally new scene (new level, menu...) makes old knowledge less reliable.
            if (reward > 0.45f) forgetHalf()
        }

        // 2) Choose the next arm: learned value + exploration bonus + "looks like a button" prior.
        val sal = saliency(frame)
        t++
        var best = 0
        var bestScore = -1e9f
        for (arm in 0 until arms) {
            val bonus = 0.6f * sqrt(ln(t.toFloat()) / (uses[arm] + 1))
            val prior = if (arm < cells) 0.35f * sal[arm] else 0.05f
            val score = value[arm] + bonus + prior + rnd.nextFloat() * 0.02f
            if (score > bestScore) {
                bestScore = score
                best = arm
            }
        }
        lastArm = best

        // 3) Turn the arm into an action.
        if (best < cells) {
            val r = best / cols
            val c = best % cols
            val x = (c + 0.2f + rnd.nextFloat() * 0.6f) / cols
            val y = (r + 0.2f + rnd.nextFloat() * 0.6f) / rows
            val v = String.format(Locale.US, "%.2f", value[best])
            return Decision(GameAction.Tap(x, y), "Exploring cell r$r c$c (value $v)", "tap r$r c$c")
        }
        return when (best - cells) {
            0 -> swipe(0.80f, 0.50f, 0.20f, 0.50f, "left")
            1 -> swipe(0.20f, 0.50f, 0.80f, 0.50f, "right")
            2 -> swipe(0.50f, 0.75f, 0.50f, 0.25f, "up")
            else -> swipe(0.50f, 0.25f, 0.50f, 0.75f, "down")
        }
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, name: String) =
        Decision(GameAction.Swipe(x1, y1, x2, y2, 280L), "Trying a swipe $name", "swipe $name")

    private fun forgetHalf() {
        for (i in 0 until arms) {
            value[i] *= 0.5f
            uses[i] = uses[i] / 2
        }
    }

    /** Per-cell "button-likeness" in 0..1: colourful + high local contrast. */
    private fun saliency(frame: Bitmap): FloatArray {
        val gw = cols * 4
        val gh = rows * 4
        val small = Bitmap.createScaledBitmap(frame, gw, gh, true)
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)
        if (small !== frame) small.recycle()

        val out = FloatArray(cells)
        val hsv = FloatArray(3)
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                var colourful = 0f
                var sum = 0f
                var sumSq = 0f
                for (dy in 0 until 4) {
                    for (dx in 0 until 4) {
                        Color.colorToHSV(px[(r * 4 + dy) * gw + (c * 4 + dx)], hsv)
                        colourful += hsv[1] * hsv[2]
                        sum += hsv[2]
                        sumSq += hsv[2] * hsv[2]
                    }
                }
                val mean = sum / 16f
                val variance = (sumSq / 16f - mean * mean).coerceAtLeast(0f)
                out[r * cols + c] = colourful / 16f + sqrt(variance)
            }
        }
        val max = out.maxOrNull() ?: 0f
        if (max > 0f) {
            for (i in out.indices) out[i] = out[i] / max
        }
        return out
    }
}
