package com.zirexhub.autoplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * The heart of the app. As an accessibility service it can
 *  - take screenshots of whatever app is in front (API 30+),
 *  - inject taps / swipes (dispatchGesture),
 *  - show a small floating PLAY/STOP chip on top of any game.
 * When you press PLAY it runs the loop: screenshot -> brain decides -> perform gesture -> repeat.
 */
class AutoPlayService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoPlayService"

        @Volatile
        var instance: AutoPlayService? = null

        @Volatile
        var statusText: String = "Idle"
    }

    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null

    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private var playBtn: TextView? = null
    private var statusView: TextView? = null

    // ---------------------------------------------------------------- service lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setStatus("Service connected. Open a game and press PLAY.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed: we work from screenshots, not from the view tree.
    }

    override fun onInterrupt() {
        // Nothing to do.
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopAgent(null)
        removeOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- agent control

    fun isRunning(): Boolean = running.get()

    fun toggle() {
        if (running.get()) stopAgent("Stopped.") else startAgent()
    }

    fun startAgent() {
        if (worker?.isAlive == true) {
            setStatus("Still stopping, press PLAY again in a second.")
            return
        }
        val brain = createBrain() ?: return
        if (running.getAndSet(true)) return
        setStatus("Starting...")
        updatePlayButton()
        worker = Thread({ runLoop(brain) }, "autoplay-agent").also { it.start() }
    }

    fun stopAgent(message: String?) {
        running.set(false)
        worker?.interrupt()
        if (message != null) setStatus(message)
        updatePlayButton()
    }

    private fun createBrain(): Brain? {
        return if (Prefs.mode(this) == Prefs.MODE_AI) {
            val key = Prefs.apiKey(this)
            if (key.isBlank()) {
                setStatus("No API key. Add it in the app, or switch to Offline mode.")
                null
            } else {
                ClaudeBrain(key, Prefs.model(this))
            }
        } else {
            HeuristicBrain()
        }
    }

    // ---------------------------------------------------------------- the main loop

    private fun runLoop(brain: Brain) {
        val goal = Prefs.goal(this)
        val delayMs = Prefs.delayMs(this)
        val history = ArrayList<String>()
        var prevThumb: IntArray? = null
        var stuck = 0
        var shotFailures = 0
        var aiFailures = 0
        var step = 0

        try {
            while (running.get()) {
                val frame = captureBlocking()
                if (frame == null) {
                    shotFailures++
                    setStatus("Screenshot failed ($shotFailures/5). Secure screen?")
                    if (shotFailures >= 5) {
                        stopAgent("Cannot capture the screen. This app may block screenshots.")
                        break
                    }
                    Thread.sleep(1200)
                    continue
                }
                shotFailures = 0

                val w = frame.width
                val h = frame.height
                val thumb = FrameTools.thumb(frame)
                val change = prevThumb?.let { FrameTools.diff(it, thumb) }
                prevThumb = thumb
                if (change != null) {
                    if (change < 0.004f) stuck++ else stuck = 0
                }

                step++
                setStatus("Step $step: thinking...")

                val decision: Decision = try {
                    brain.decide(frame, AgentContext(goal, history.takeLast(8), change, stuck))
                        .also { aiFailures = 0 }
                } catch (e: ClaudeBrain.AuthException) {
                    stopAgent("API key rejected: ${e.message}")
                    break
                } catch (e: InterruptedException) {
                    throw e
                } catch (e: Exception) {
                    aiFailures++
                    Log.w(TAG, "brain error", e)
                    setStatus("AI error, retrying: ${e.message?.take(80)}")
                    prevThumb = null
                    step--
                    Thread.sleep((2000L * aiFailures).coerceAtMost(15000L))
                    continue
                } finally {
                    frame.recycle()
                }

                if (!running.get()) break

                val action = decision.action
                history.add("$step. ${decision.label} - ${decision.note}")
                setStatus("Step $step: ${decision.note.ifBlank { decision.label }}")

                if (action is GameAction.Finish) {
                    stopAgent("Finished: ${action.reason}")
                    break
                }

                val ok = execute(action, w, h)
                if (!ok) Log.w(TAG, "gesture failed or was cancelled: ${decision.label}")

                Thread.sleep(delayMs)
            }
        } catch (_: InterruptedException) {
            // stopAgent() interrupted us.
        } catch (t: Throwable) {
            Log.e(TAG, "agent crashed", t)
            setStatus("Agent crashed: ${t.message}")
        } finally {
            running.set(false)
            setPassThrough(false) // never leave the floating chip untouchable
            updatePlayButton()
        }
    }

    // ---------------------------------------------------------------- screen capture

    private fun captureBlocking(): Bitmap? {
        val latch = CountDownLatch(1)
        var result: Bitmap? = null
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        try {
                            val hw = screenshot.hardwareBuffer
                            val wrapped = Bitmap.wrapHardwareBuffer(hw, screenshot.colorSpace)
                            result = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                            wrapped?.recycle()
                            hw.close()
                        } catch (t: Throwable) {
                            Log.w(TAG, "screenshot decode failed", t)
                        } finally {
                            latch.countDown()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        Log.w(TAG, "screenshot failed, code $errorCode")
                        latch.countDown()
                    }
                },
            )
        } catch (t: Throwable) {
            Log.w(TAG, "takeScreenshot threw", t)
            return null
        }
        latch.await(5, TimeUnit.SECONDS)
        return result
    }

    // ---------------------------------------------------------------- gestures

    private fun execute(a: GameAction, w: Int, h: Int): Boolean = when (a) {
        is GameAction.Tap -> {
            var ok = true
            for (i in 0 until a.count) {
                val p = Path().apply { moveTo(a.x * w, a.y * h) }
                ok = dispatch(p, 50L) && ok
                if (i < a.count - 1) Thread.sleep(70)
            }
            ok
        }
        is GameAction.LongPress -> {
            val p = Path().apply { moveTo(a.x * w, a.y * h) }
            dispatch(p, a.ms)
        }
        is GameAction.Swipe -> {
            val p = Path().apply {
                moveTo(a.x1 * w, a.y1 * h)
                lineTo(a.x2 * w, a.y2 * h)
            }
            dispatch(p, a.ms)
        }
        is GameAction.Wait -> {
            Thread.sleep(a.ms)
            true
        }
        is GameAction.Back -> performGlobalAction(GLOBAL_ACTION_BACK)
        is GameAction.Finish -> true
    }

    /** Performs one stroke and blocks until Android reports it finished. */
    private fun dispatch(path: Path, durationMs: Long): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L)))
            .build()

        // Let the touch go "through" our own floating chip while the gesture runs.
        setPassThrough(true)
        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok = true
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null,
        )
        try {
            if (accepted) latch.await(durationMs + 2000L, TimeUnit.MILLISECONDS)
        } finally {
            setPassThrough(false)
        }
        return accepted && ok
    }

    // ---------------------------------------------------------------- floating chip

    fun showOverlay() {
        main.post {
            if (overlay != null) return@post
            val ctx: Context = this
            val density = resources.displayMetrics.density
            fun dp(v: Int) = (v * density).toInt()

            val grip = TextView(ctx).apply {
                text = "≡"
                textSize = 22f
                setTextColor(0xFF8FA3B8.toInt())
                setPadding(dp(10), dp(4), dp(6), dp(4))
            }
            val play = TextView(ctx).apply {
                text = "PLAY"
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setTextColor(0xFF06210F.toInt())
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = pill(0xFF35E0A1.toInt(), dp(20).toFloat())
                setOnClickListener { toggle() }
            }
            val status = TextView(ctx).apply {
                text = "Open your game, then press PLAY"
                textSize = 11f
                setTextColor(0xFFD5DEE8.toInt())
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                maxWidth = dp(150)
                setPadding(dp(8), 0, dp(6), 0)
            }
            val close = TextView(ctx).apply {
                text = "X"
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFFFF8A80.toInt())
                setPadding(dp(8), dp(6), dp(12), dp(6))
                setOnClickListener {
                    stopAgent("Stopped.")
                    removeOverlay()
                }
            }

            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = pill(0xEE101820.toInt(), dp(26).toFloat())
                setPadding(dp(4), dp(4), dp(4), dp(4))
                addView(grip)
                addView(play)
                addView(status)
                addView(close)
            }

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = dp(8)
                y = dp(140)
            }

            // Drag the chip by its grip.
            grip.setOnTouchListener(object : View.OnTouchListener {
                var startX = 0f
                var startY = 0f
                var originX = 0
                var originY = 0
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = e.rawX
                            startY = e.rawY
                            originX = lp.x
                            originY = lp.y
                        }
                        MotionEvent.ACTION_MOVE -> {
                            lp.x = originX + (e.rawX - startX).toInt()
                            lp.y = originY + (e.rawY - startY).toInt()
                            try {
                                wm.updateViewLayout(box, lp)
                            } catch (_: Exception) {
                            }
                        }
                    }
                    return true
                }
            })

            try {
                wm.addView(box, lp)
                overlay = box
                overlayLp = lp
                playBtn = play
                statusView = status
                status.text = statusText
                updatePlayButton()
            } catch (t: Throwable) {
                Log.e(TAG, "cannot show overlay", t)
            }
        }
    }

    fun removeOverlay() {
        main.post {
            overlay?.let {
                try {
                    wm.removeView(it)
                } catch (_: Exception) {
                }
            }
            overlay = null
            overlayLp = null
            playBtn = null
            statusView = null
        }
    }

    private fun pill(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun updatePlayButton() {
        main.post {
            val btn = playBtn ?: return@post
            val on = running.get()
            btn.text = if (on) "STOP" else "PLAY"
            btn.background = pill(
                if (on) 0xFFFF6B6B.toInt() else 0xFF35E0A1.toInt(),
                (20 * resources.displayMetrics.density),
            )
        }
    }

    private fun setPassThrough(on: Boolean) {
        onMainSync {
            val v = overlay ?: return@onMainSync
            val lp = overlayLp ?: return@onMainSync
            lp.flags = if (on) {
                lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            } else {
                lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            }
            try {
                wm.updateViewLayout(v, lp)
            } catch (_: Exception) {
            }
        }
    }

    private fun onMainSync(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
            return
        }
        val latch = CountDownLatch(1)
        main.post {
            try {
                block()
            } finally {
                latch.countDown()
            }
        }
        try {
            latch.await(2, TimeUnit.SECONDS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt() // keep the stop signal, the block is already queued
        }
    }

    private fun setStatus(s: String) {
        statusText = s
        main.post { statusView?.text = s }
    }
}
