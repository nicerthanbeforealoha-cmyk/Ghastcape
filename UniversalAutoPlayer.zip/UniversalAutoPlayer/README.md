# Universal AutoPlayer (ZirexHub build)

An Android app that plays games for you. It takes a screenshot of whatever is on screen, decides
what to do, taps or swipes, and repeats. A small floating PLAY/STOP chip sits on top of any game.

## Two brains

| Brain | Needs | What it does |
|---|---|---|
| **AI player** (default) | Internet + Anthropic API key | Sends each screenshot (plus your last actions and whether the screen changed) to Claude vision. Claude works out the game, picks one action, and adapts when something does not work. Works on puzzle, card, idle/clicker, tap and turn-based games. |
| **Offline explorer** | Nothing | No understanding of the game. It learns by trial and error which screen areas and swipes change the screen, and keeps using those. Fine for tap-to-progress and simple casual games. |

## Honest limits

- No app can win every game. The AI brain reacts about once every few seconds, so fast reflex
  games (runners, shooters, rhythm) will not work well. Slow and turn-based games will.
- Use it on offline / single-player games. Bots in online competitive games usually break the
  rules and can get the account banned.
- Some apps block screenshots (banking apps, some video apps). The agent stops with a message.
- AI mode sends screenshots of your screen to the Claude API and costs a little per step.
  Your key is stored on the phone only (plain app storage), so use a key with a spend limit.
- Needs Android 11+ (API 30), because that is when accessibility services got screenshots.

## Build the APK

I could not compile it in my sandbox (no Android SDK, no access to Google's servers), so the
build happens on your side. Pick one:

### A) GitHub (no PC needed beyond a browser)
1. Create a free account at github.com and a new empty repository.
2. Upload every file and folder of this project (keep the `.github` folder, it holds the build).
3. Open the repo's **Actions** tab. The *Build APK* workflow runs by itself (or press
   *Run workflow*).
4. When it is green, open the run and download **UniversalAutoPlayer-debug-apk**. Unzip it and
   install `app-debug.apk` on your phone (allow "install unknown apps" for your file manager).

### B) Android Studio
1. Open this folder in Android Studio (Ladybug or newer) and let Gradle sync.
2. *Build > Build Bundle(s) / APK(s) > Build APK(s)*.
3. The file is `app/build/outputs/apk/debug/app-debug.apk`.

### C) Command line
```
./gradlew assembleDebug
```
(needs JDK 17 and the Android SDK with platform 35)

## First run on the phone

1. Open the app and press **Open accessibility settings**. Turn on **Universal AutoPlayer**.
   - If Android says *Restricted setting* (Android 13+, apps installed from an APK file):
     Settings > Apps > Universal AutoPlayer > three-dot menu > **Allow restricted settings**,
     then turn the service on again.
2. Back in the app paste your Anthropic API key (or switch off the AI switch for offline mode).
   Optionally add a hint such as "Match-3 game, make big combos". Press **Save settings**.
3. Press **Pick a game and launch it**, choose the game. A floating chip appears over it.
4. When the game is ready, press **PLAY** on the chip. Press **STOP** any time.
   Drag the chip by the three-line grip if it covers something.

## Settings

- **Model**: default `claude-sonnet-5-5`. Change it if your account uses another model name.
- **Seconds between actions**: extra pause after each action (default 1.5 s).
- **Hint**: free text that is added to every request.

## How it works (for tinkering)

```
app/src/main/java/com/zirexhub/autoplayer/
  MainActivity.kt    settings screen, game picker
  AutoPlayService.kt accessibility service: screenshots, gestures, floating chip, the main loop
  ClaudeBrain.kt     calls the Claude Messages API with the screenshot, parses the JSON action
  HeuristicBrain.kt  offline explorer (bandit over a screen grid + swipes)
  FrameTools.kt      thumbnails, change detection, JPEG/base64
  Brain.kt           GameAction / Decision / Brain interface
  Prefs.kt           saved settings
```

Add your own brain by implementing `Brain` and returning it from `AutoPlayService.createBrain()`.
The safety rules for the AI (no purchases, no logins, never tap ads) live in `SYSTEM_PROMPT`
inside `ClaudeBrain.kt`.
